#title: "EtherAnalysis"
#author: "Adharsh Rajendran"
#date: "February 26, 2019"

library(plyr)
library(ggplot2)

#set working directory to project folder

setwd('C:/Users/Adharsh/Documents/2019_Spring/Statistics/R Project')

#read in text file of ether token
df <- read.csv(file = "ether.txt", header = T, sep = "  ")

#display summary of results
summary(df)
#head(df)
